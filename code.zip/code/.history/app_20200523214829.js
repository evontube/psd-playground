function demo() {
  console.log("abc");
}
demo();
const demo = function() {
  alert("abc");
};
