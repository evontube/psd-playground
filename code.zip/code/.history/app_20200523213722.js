function demo() {
  console.log("abc");
}
demo();
